def quad_tube (pts, r, n, close = False, tex_rate = 4):
    perimeter = TAU * r
    k = len(pts)
    if k < 2: 
        return
    if close:
        prev_dir = pts[0].copy().sub(pts[k-1])
    else:
        prev_dir = pts[1].copy().sub(pts[0])
    prev_p = None
    prev_ring = None
    prev_t = t = 0
    begin_shape(QUAD_STRIP)
    for i in range (k+1 if close else k):
        p = pts[i%k]
        if i == k-1 and not close:
            dir = prev_dir.copy()
        else:
            next_p = pts[(i+1)%k]
            dir = next_p.copy().sub(p)
        next_t = t + dir.mag() / perimeter * tex_rate
        ring = ring_vectors (dir.copy().add(prev_dir).normalize(), r, n)
        
        if prev_ring:
            for j,(v1,v2) in enumerate(zip ([*prev_ring, prev_ring[0]], 
                [*ring, ring[0]])):
                s = j / n * tex_rate
                norm = v1.copy().normalize()
                normal (norm.x, norm.y, norm.z)
                a = prev_p.copy().add(v1)
                vertex(a.x,a.y,a.z, s, prev_t)
                norm = v2.copy().normalize()
                normal (norm.x, norm.y, norm.z)
                b = p.copy().add(v2)
                vertex(b.x,b.y,b.z, s, t)
        prev_t, t = t, next_t
        prev_dir = dir
        prev_ring = ring
        prev_p = p
    end_shape()

def ring_vectors (dir, r, n):
    normal = dir.copy().normalize()
    
    if abs(normal.z) > 0.99:
        arbitrary = createVector(1, 0, 1);
    else:
        arbitrary = createVector(0, 0, 1);
        
    u = p5.Vector.cross(normal, arbitrary).normalize()
    v = p5.Vector.cross(normal, u).normalize();
    vectors = []
    for i in range(n):
        theta = TWO_PI * i / n
        vU = p5.Vector.mult(u, cos(theta) * r)
        vV = p5.Vector.mult(v, sin(theta) * r);
        vectors.append (p5.Vector.add(vU,vV))
    return vectors