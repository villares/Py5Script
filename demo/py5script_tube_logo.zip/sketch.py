from hershey_fonts import HersheyFont, font_names 
from tubes import quad_tube

def preload():
    global my_shader
    my_shader = loadShader ('shader.vert', 'shader.frag')

def setup():
    createCanvas(windowWidth, windowHeight, WEBGL)
    global font, geom
    font = HersheyFont("cursive")
    global geom
    begin_geometry()

    sfactor = 5
    for strk in font.text_strokes("Py5Script"):
        pts = []
        for p in strk:
            pts.append (createVector(*p).mult(sfactor))
        if pts[0].dist(pts[len(pts)-1]) < 0.1: 
            close = True
            pts.pop()
        else: 
            close = False
        quad_tube(pts, sfactor*2.5, 8, close, 6) 
    geom = end_geometry()
        
    texture (create_texture())
    textureMode (NORMAL)
    textureWrap (REPEAT,REPEAT)
    

def create_texture ():
    pg = createGraphics(256, 256)
    pg.background('#444')
    pg.noStroke()
    pg.fill('#CCC')
    #pg.rect(0,0,128,128)
    #pg.circle (128,128,210)
    #pg.rect (0,0,180,180)
    pg.stroke('#FFF')
    pg.strokeWeight (90)
    pg.line (0,0,256,256)
    pg.line (-256,0,256,512)
    pg.line (0,-256,512,256)
    
    return pg.get()

def key_pressed():
    if key == 's': save('logo.png')
    
def draw ():
    clear()
    orbit_control()
    lights()
    shader(my_shader)
    ds = (frame_count/30)%1
    dt = (frame_count/15)%1
    my_shader.setUniform('uShiftTexture', [ds,dt])
    noStroke()
    sfactor = 5
    translate (-80*sfactor, -15*sfactor)
    model(geom)
