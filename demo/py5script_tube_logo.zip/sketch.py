from hershey_fonts import HersheyFont, font_names 
from tubes import quad_tube
from smooth_curve import four_point

def preload():
    global my_shader
    my_shader = loadShader ('shader.vert', 'shader.frag')

def setup():
    createCanvas(windowWidth, windowHeight, WEBGL)
    global font, geom

    make_interface()
    
    set_font()
    
    create_geometry()
   
    create_texture()

def set_font ():
    global font, font_name
    font = HersheyFont(font_name.selected())
    

def make_interface():
    global fg_color, bg_color, tex_pattern, s_tex_mult, t_tex_mult, font_name
    from pyodide.ffi import create_proxy
    
    def label (text, x, y, element):
        lab = create_element("span", text)
        lab.position (x, y)
        lab.style("color", "white")
        element.position (x+100, y)
        
    def make_select (*options):
        sel = create_select()
        for op in options:
            sel.option(op)
        return sel

    fg_color = create_color_picker('darkgray')
    label("foreground", 10, 10, fg_color)
    
    bg_color = create_color_picker('white')
    label("background", 10, 40, bg_color)
    
    tex_pattern = make_select('circles','diagonal stripes','horiz stripes',
        'vert stripes')
    tex_pattern.selected("circles")
    label("texture", 10,70, tex_pattern)
    
    create_texture_call = create_proxy(lambda event: create_texture())
    for element in [fg_color, bg_color, tex_pattern]:
        element.changed (create_texture_call)
        
    s_tex_mult = createSlider (1,10,2,0.2)
    label("S tex. mult.", 10, 100, s_tex_mult)
    t_tex_mult = createSlider (1,10,2,0.2)
    label("T tex. mult.", 10, 130, t_tex_mult)
    
    font_name = make_select ('futural', 'scriptc', 'cursive', 'timesr')
    font_name.selected("cursive")
    label("font", 10, 160, font_name)
    def recreate_geometry ():
        set_font ()
        create_geometry()
    font_name_call = create_proxy(lambda event:recreate_geometry())
    font_name.changed(font_name_call)
    
    
    # Prevent the elements from propagating events to the underlying canvas
    prevent_call = create_proxy(
        lambda event:
            event.stopPropagation()
        )
    for item in [fg_color, bg_color, tex_pattern, s_tex_mult, 
        t_tex_mult, font_name]:
        item.elt.addEventListener('mousedown', prevent_call)
    
def create_geometry():
    global geom
    begin_geometry()
    sfactor = 5
    for strk in font.text_strokes("Py5Script"):
        pts = []
        close = dist(*strk[0], *strk[len(strk)-1]) < 0.1
        if close: strk = strk[:-1]
        strk = four_point(strk, close)
        for p in strk:
            pts.append (createVector(*p).mult(sfactor))
        quad_tube(pts, sfactor*2.5, 12, close, 1) 
    geom = end_geometry()

def create_texture ():
    pg = createGraphics(256, 256)
    pg.background(bg_color.color())
    pg.noStroke()
    pg.fill(fg_color.color())
    if tex_pattern.selected() == 'circles':
        #pg.rect(0,0,128,128)
        pg.circle (128,128,210)
        #pg.rect (0,0,180,180)
    elif tex_pattern.selected() == 'diagonal stripes':
        pg.stroke(fg_color.color())
        pg.strokeWeight (90)
        pg.line (0,0,256,256)
        pg.line (-256,0,256,512)
        pg.line (0,-256,512,256)
    elif tex_pattern.selected() == 'horiz stripes':
        pg.rect(0,0,256,128)
    elif tex_pattern.selected() == 'vert stripes':
        pg.rect(0,0,128,256)
    
    img = pg.get()
    texture (img)
    textureMode (NORMAL)
    textureWrap (REPEAT,REPEAT)

def key_pressed():
    if key == 's': save('logo.png')
    
def draw ():
    clear()
    orbit_control()
    lights()
    shader(my_shader)
    ds = (frame_count/30)%1
    dt = (frame_count/15)%1
    my_shader.setUniform('uScaleTexture', [s_tex_mult.value(),t_tex_mult.value()])
    my_shader.setUniform('uShiftTexture', [ds,dt])
    noStroke()
    sfactor = 5
    translate (-80*sfactor, -15*sfactor)
    model(geom)
