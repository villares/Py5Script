import json

with open('hersheytext.min.json', 'r') as file:
    hershey = json.load(file)

font_names = list(hershey.keys())

class HersheyFont:
    
    smooth = False
    
    def __init__(self, font_name, pace = 2):
        data = hershey[font_name]
        self.stock = 1e10
        self.name = data["name"]
        self.pace = pace
        self.chars = {}
        for i,datum in enumerate(data["chars"]):
            geom = []
            for cmd in datum["d"].split(" "):
                if len(cmd)==0: continue
                if cmd[0] in "ML":
                    if cmd[0]=="M":
                        geom.append([])
                    cmd = cmd[1:]
                xs,ys = cmd.split(",")
                x = int(xs)
                y = int(ys)
                geom[-1].append([x,y])
            self.chars[chr(i+33)] = { "width" : datum["o"], "strokes" : geom }
    def draw_char(self, ch, x0 = 0, y0 = 0):
        for strk in self.chars[ch]["strokes"]:
            if self.stock <= 0: break
            begin_shape()
            if HersheyFont.smooth:
                vertex(strk[0][0]+x0,strk[0][1]+y0)
                for x,y in strk:
                    self.stock -=1
                    if self.stock < 0: break
                    curve_vertex(x+x0,y+y0)
                vertex(x+x0,y+y0)
            else:
                for x,y in strk:
                    self.stock -=1
                    if self.stock < 0: break
                    vertex(x+x0,y+y0)
            end_shape()
    def draw_text(self, text, x0 = 0, y0 = 0):
        for ch in text:
            if ch in self.chars:
                self.draw_char(ch, x0, y0)
                x0 += self.chars[ch]["width"]*2 + self.pace
            else:
                x0 += 10
        return x0
    def text_strokes (self, text, x0 = 0, y0 = 0):
        strokes = []
        for ch in text:
            if self.stock < 0: break 
            if ch in self.chars:
                for strk in self.chars[ch]["strokes"]:
                    if self.stock < 0: break 
                    stroke = []
                    strokes.append(stroke)
                    for x,y in strk:
                        self.stock -=1
                        if self.stock < 0: break 
                        stroke.append((x+x0,y+y0))
                x0 += self.chars[ch]["width"]*2 + self.pace
            else:
                x0 += 10
        return strokes
