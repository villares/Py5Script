from hershey_fonts import HersheyFont, font_names 

def setup():
    createCanvas(windowWidth, windowHeight)
    global font, stock, max_stock, color1, color2
    font = HersheyFont("futural")
    HersheyFont.smooth = False
    font.stock = 1000
    font.draw_text("Py5Script")
    max_stock = 1000-font.stock
    color1 = color('red')
    color2 = color('#0AA')
    stock = max_stock
    background(255)
    
def mouse_clicked():
    global stock, max_stock
    background(255)
    stock = max_stock

def draw ():
    #background(255)
    no_fill()
    translate (50, 50)
    scale(4)
    stroke_weight(1.5)
    global stock, font, color1, color2, max_stock
    stroke (lerp_color (color1, color2, stock/max_stock))
    font.stock = stock
    font.draw_text("Py5Script")
    if stock > 0: stock -= 1
    
