from test_module import name

def setup():
    createCanvas(400, 400)
    background(220)
    textSize (50)
    textAlign (CENTER, CENTER)
    text ("Hi, "+name, width/2, height/2)
