"""
A demo trying to mimic p5's builtin Phong illumination shader.
"""
def preload():
    global myShader
    myShader = loadShader('shader.vert', 'shader.frag')

def setup():
    createCanvas(windowWidth, windowHeight, WEBGL)

def draw():
    background(220)
    orbitControl()
    lights()
    noStroke()
    shader (myShader)
    r1 = min(width,height) / 3
    r2 = r1/4
    torus (r1, r2)
