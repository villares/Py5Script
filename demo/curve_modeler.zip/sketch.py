from smooth_curves import lr, four_point

def setup():
    createCanvas(windowWidth, windowHeight)
    global pts, subdivide
    s = min(width,height)/4
    x = width/2
    y = height/2
    pts = [[x-s,y-s], [x+s, y-s], [x+s, y+s]]
    make_interface()

def draw():
    background(220)
    global pts, subdivide
    
    push()
    begin_shape()
    no_fill()
    stroke_weight(2)
    sub = pts
    for i in range(4): sub = subdivide (sub, close_check.checked())
    for x,y in sub: vertex(x,y)
    end_shape(CLOSE if close_check.checked() else False)
    pop()
    
    for x,y in pts:
        circle (x, y, 10, 10)

def make_interface():
    global close_check, smooth_algorithm, subdivide
    from pyodide.ffi import create_proxy
    
    def label (text, x, y, element):
        lab = create_element("span", text)
        lab.position (x, y)
        lab.style("color", "black")
        element.position (x+100, y)
    
    close_check = create_checkbox ()
    label("close", 10, 10, close_check)
    
    smooth_algorithm = create_select()
    smooth_algorithm.option ("Lane-Riesenfeld")
    smooth_algorithm.option ("4-point")
    smooth_algorithm.selected ("Lane-Riesenfeld")
    label ("algorithm", 10, 40, smooth_algorithm)
    
    def set_subdivide ():
        global subdivide
        
        if smooth_algorithm.selected() == "Lane-Riesenfeld":
            subdivide = lr
        else:
            subdivide = four_point
    
    set_subdivide()
    
    set_subdivide_call = create_proxy(lambda event: set_subdivide())
    smooth_algorithm.changed(set_subdivide_call)
    
    # Prevent the elements from propagating events to the underlying canvas
    prevent_call = create_proxy(
        lambda event:
            event.stopPropagation()
        )
    for item in [close_check, smooth_algorithm]:
        item.elt.addEventListener('mousedown', prevent_call)
    

def mouse_pressed():
    global selected, pts
    selected = None
    for p in pts:
        x, y = p
        if dist(x,y,mouse_x, mouse_y) < 10:
            selected = p
    if not selected:
        j = -1
        min_d = 1e10
        p = [mouse_x, mouse_y]
        n = len(pts)
        k = n+1 if close_check.checked() else n
        for i in range (1,k):
            d = dist_segment (p, pts[i-1], pts[i%n])
            if d < min_d:
                min_d = d
                j = i
        pts = pts[:j] + [p] + pts[j:]
        selected = pts[j]

def mouse_dragged():
    global selected
    if selected:
        p = selected
        p[0]+=mouse_x-pmouse_x
        p[1]+=mouse_y-pmouse_y

def dist_segment (p, a, b):
    p = create_vector (*p)
    a = create_vector (*a)
    b = create_vector (*b)
    v = b.copy().sub(a)
    u = p.copy().sub(a)
    vlen = v.mag()
    vnorm = v.copy().normalize()
    proj_size = vnorm.dot(u)
    if proj_size > vlen: return p.dist(b)
    if proj_size < 0: return p.dist(a)
    return p.sub(a.lerp(b, proj_size / vlen)).mag()
