def setup():
	global D, grad
	createCanvas(windowWidth, windowHeight);
	D = min(width,height);
	grad = drawingContext.createLinearGradient(0, 0, 0, height)
	grad.addColorStop(0, "white")
	grad.addColorStop(1, "black")


def draw():
	global grad
	timing = 300;
	drawingContext.fillStyle = grad;
	drawingContext.fillRect(0, 0, width, height);
	t = (frameCount % (timing))/(timing-1);
	if frameCount % (2*timing) >= timing: t = 1-t;
	sgn = -1 if frameCount % (4*timing) >= 2*timing else 1
	turns = lerp(0.05,8,t)
	steps = lerp(20,10,t)
	spacing = D*0.3/turns
	pace = spacing/steps
	translate(width/2, height/2)
	noStroke()
	black = first = True
	i = steps*turns
	while i > 0:
		turn = i/steps;
		v = createVector (i*pace,0).rotate(sgn*TAU*(turns-turn));
		if black or (i-1) <= 0: 
			fill ('black')
		else:
			fill('white');
		black= not black;
		if not first:
			circle (v.x, v.y, spacing*(turn+0.5));
		first = False
		i -=1 
	
