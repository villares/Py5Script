def preload():
    global img
    img = loadImage("zerbini.jpg")
    print ("loaded")

def setup():
    createCanvas(400, 400)
    print ("test")

def draw():
    image(img, 0,0, 400, 400)
    ellipse(mouseX, mouseY, 50, 50)
