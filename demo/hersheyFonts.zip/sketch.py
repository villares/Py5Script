from hershey_fonts import HersheyFont, font_names 

def setup():
    createCanvas(windowWidth, windowHeight)
    global font, ifont
    ifont = 0
    font = HersheyFont(font_names[ifont])
    show_font()
    
def mouse_clicked():
    global font, ifont
    ifont = (ifont+1) % len(font_names)
    font = HersheyFont(font_names[ifont])
    show_font()
    
def show_font ():
    n_glyphs = len(font.chars.keys())
    margin_top = 50
    margin = 50
    w = width - margin*2 - margin_top
    h = height - margin*2
    
    cell_size = int(sqrt(w*h/n_glyphs))
    cols = int(w/cell_size)
    rows = int(h/cell_size)
    while cols*rows < n_glyphs:
        cell_size -= 1
        cols = int(w/cell_size)
        rows = int(h/cell_size)

    
    margin_left = (width - cols * cell_size) / 2
    margin_top += (height - margin_top - rows * cell_size) / 2
    x0,y0 = margin_left, margin_top
    
    background(255)
    fill('black')
    textSize (20)
    text(f"{font.name} ({font_names[ifont]})", margin_left, margin)
    noFill()
    i = 0
    
    char_size = 35
    sfactor = cell_size /char_size * 0.8
    padding = (cell_size - sfactor * char_size) / 2
    
    for ch in font.chars.keys():
        square(x0,y0,cell_size)
        push()
        translate (x0+padding, y0+padding)
        scale(sfactor)
        font.draw_text(ch, 0, 0)
        pop()
        x0 += cell_size
        i += 1
        if i % cols == 0:
            x0 = margin_left
            y0 += cell_size
        