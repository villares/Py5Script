from tubes import quad_tube

def preload():
    global my_shader
    my_shader = loadShader ('shader.vert', 'shader.frag')

def setup():
    createCanvas(windowWidth, windowHeight, WEBGL)
    global geom
    begin_geometry()
    pts = []
    r = 100
    for ang in range (0, 360, 10):
        p = createVector(r,0).rotate(radians(ang))
        pts.append(p)
    quad_tube (pts, 50, 12, True, 12)
    geom = end_geometry()
    
    texture (create_texture())
    textureMode (NORMAL)
    textureWrap (REPEAT,REPEAT)


def create_texture ():
    pg = createGraphics(256, 256)
    pg.background(255)
    pg.noStroke()
    pg.fill('red')
    pg.rect(0,0,128,128)
    return pg.get()
    


def draw():
    background (100)
    orbit_control()
    shader(my_shader)
    ds = cos(radians(frame_count)*2)
    dt = (frame_count/10)%1
    my_shader.setUniform('uShiftTexture', [ds,dt])
    lights()
    noStroke()
    model (geom)

        
